
---
title: "Publications"
permalink: /publications/
---

List your representative works below. You can keep it simple with Markdown or paste formatted references.

#### Selected Publications
1. **Title.** Authors. *Venue/Journal*, Year. [[PDF]](#) [[Code]](#) [[BibTex]](#)
2. **Title.** Authors. *Venue/Journal*, Year. [[PDF]](#) [[Code]](#)

> Optional: maintain a `papers.bib` file and link it here: [BibTeX file](/_bibliography/papers.bib).
> GitHub Pages does not build `jekyll-scholar`, so the list is manual; keep it curated and concise.
