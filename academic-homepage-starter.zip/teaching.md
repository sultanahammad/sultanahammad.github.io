
---
title: "Teaching"
permalink: /teaching/
---

### Current / Recent Courses
- **Digital Content Design and Development** — Undergraduate
- **Big Data Analytics and Data Engineering** — Postgraduate
- **Object-Oriented Analysis & Design**, **Web Engineering** — Undergraduate

### Supervision
- MSc theses on Big Data, Blockchain, AI-driven Cybersecurity (ongoing).

### Materials
Add links to public syllabi, slides, labs, or GitHub repos for each course.

