
---
title: "Vacancies"
permalink: /vacancies/
---

I welcome motivated students interested in **AI/ML**, **Cybersecurity**, **Blockchain**, and **Software Engineering**.

**How to reach out**
- Email subject: `Prospective Student – [Your Name] – [Interest Area]`
- Include: CV (PDF), transcripts, links to code/papers.
- Mention 1–2 recent works of mine you read and what you want to explore.

> Collaboration ideas are welcome (industry/academia). Remote reading groups or small projects are possible.

