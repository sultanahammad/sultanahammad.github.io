
---
title: "Home"
permalink: /
---

Welcome! I’m **Mohd. Sultan Ahammad**, Assistant Professor in the Department of Computer Science & Engineering at **MBSTU**, Bangladesh.

**Research interests:** Digital Security, Machine Learning, Deep Learning, Cybersecurity, and Software Engineering.

### News
- *[YYYY-MM-DD]* Paper submitted to **[Venue]** on **[Topic]**.
- *[YYYY-MM-DD]* Invited talk on **[Topic]** at **[Place]**.

> Replace the placeholders above with your real updates. Keep each item short and dated.

### Contact
- Email: <sultan.ahammad36@gmail.com>
- Office: Dept. of CSE, MBSTU, Tangail, Bangladesh

